#!/bin/bash
echo "Starting Chess Online Server..."
python3 server.py 